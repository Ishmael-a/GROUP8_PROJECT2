import 'package:flutter/material.dart';
import 'package:loginandtodo/database/todo_item.dart';
import 'main.dart';
import 'database/db.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await DB.init();
  runApp(MyApp());
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}


class _MyHomePageState extends State<MyHomePage>{
  List<ToDoItem> _todo = [];
  List<Widget> get _items => _todo.map((item) => format(item)).toList();
  late int _id;
  late int user_id;
  late String status;
  late String title;

  Widget format(ToDoItem item){
    return Padding(
      padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
      child: Dismissible(
        key: Key(item.id.toString()),
        child: Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            color: Theme.of(context).colorScheme.secondary,
            shape: BoxShape.rectangle,
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Colors.black12,
                blurRadius: 10,
                offset: Offset(0.0, 10)
              )
            ]
          ),
          child: Row(children: <Widget> [Expanded(
            child: Text(item.user_id.toString(), style: TextStyle(color: Colors.white, fontSize:16)),
          ) ,
          ]
          )
        )
      ),
    );
  }

  void _save() async {
    Navigator.of(context).pop();
    ToDoItem item = ToDoItem(
      id: _id,
      user_id: user_id,
      status: status,
      title: title,
    );

    await DB.insert(ToDoItem.table, item);
    setState(() => _id = 0);
    refresh();
  }

  void initState(){
    refresh();
    super.initState();
  }

  void refresh() async{
    List<Map<String, dynamic>> _results = await DB.query(ToDoItem.table);
    _todo = _results.map((item) => ToDoItem.fromMap(item)).toList();
    setState(() {});
  }

  void _create(BuildContext context){
    showDialog(context: context,
        builder: (BuildContext context){
          return AlertDialog(
            title: Text("ADD ITEM"),
                content: Form(
              child: Column(
              mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                autofocus: true,
                decoration: InputDecoration(labelText: 'Item Name'),
                onChanged: (id) {_id = id as int;},
              )
            ],
          )
          ),
          actions: <Widget>[
            FlatButton(onPressed: () => _save(),
                       child: Text("Save")
            ),
          ],
          );
        }
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: Container(
        child: ListView(
          children: <Widget>[
            Padding(padding: EdgeInsets.fromLTRB(20, 20, 0, 10),
              child: Text("To-Do", style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
            ),
            ListView(
              children: _items,
              shrinkWrap: true,
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.redAccent,
        onPressed: () => _create(context),
        child: Icon(Icons.add,color: Colors.black,),
      ),
    );
  }

}

class Dashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final avatar = Padding(
      padding: EdgeInsets.all(20),
      child: Hero(
          tag: 'logo',
          child: SizedBox(
            height: 160,
            child:  Image.asset('images/profile.png',width:300,height:100),
          )
      ),
    );
    final description = Padding(
      padding: EdgeInsets.all(10),
      child: RichText(
        textAlign: TextAlign.justify,
        text: TextSpan(
            text: 'Anim ad ex officia nulla anim ipsum ut elit minim id non ad enim aute. Amet enim adipisicing excepteur ea fugiat excepteur enim veniam veniam do quis magna. Cupidatat quis exercitation ut ipsum dolor ipsum. Qui commodo nostrud magna consectetur. Nostrud culpa laboris Lorem aliqua non ut veniam culpa deserunt laborum occaecat officia.',
            style: TextStyle(color: Colors.black, fontSize: 20)
        ),
      ),
    );

    final buttonLogout = FlatButton(
        padding: const EdgeInsets.all(20),
        child: Text('ToDo', style: TextStyle(color: Colors.black87, fontSize: 16),),
        //onTap:(){
        //Navigator.of(context).pop();
        //},
        onPressed: () {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => MyHomePage(title: 'Flutter SignIn Page')));
          //Navigator.of(context).pop();
          //Navigator.of(context).pushNamed('/main');
        }
    );
    return SafeArea(
        child: Scaffold(
          body: Center(
            child: ListView(
              shrinkWrap: true,
              padding: EdgeInsets.symmetric(horizontal: 20),
              children: <Widget>[
                avatar,
                description,
                buttonLogout
              ],
            ),
          ),
        )
    );
  }
}